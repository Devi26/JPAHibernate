package com.cg.ams.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.ams.beans.CourseDetails;
import com.cg.ams.beans.ExamFeeDetails;
import com.cg.ams.beans.LectureDetails;
import com.cg.ams.beans.Student;
import com.cg.ams.exception.StudentDetailsNotFoundException;
import com.cg.ams.services.AMSServicesImpl;
import com.cg.ams.services.AMSServices;

public class AMSTest {
	
	static AMSServices attendenceSystemSevices;
	
	@BeforeClass
	public static void setUpTestEnv() {
		 
		attendenceSystemSevices = new AMSServicesImpl();
	}
	
	@Before
	public void setUpTestData() {
		Student student1 = new Student(51, "Devi", "Ratnala", new CourseDetails(11, "B.Tech", "4-Years"), new LectureDetails(500, 450, 50), new ExamFeeDetails(1000));
		Student  student2 = new Student(52, "Sri", "Ratnala",new  CourseDetails(12, "BE", "4-years"), new LectureDetails(500, 300, 50), new ExamFeeDetails(1000));
		/*AMSUtil.students.put(student1.getStudentID(), student1);
		AMSUtil.students.put(student2.getStudentID(), student2);
		AMSUtil.STUDENT_ID_COUNTER = 53;*/
	}
	
	@Test
	public void testAcceptStudentDetailsForValidData() {
		int expectedStudentId = 54;
		int actualStudentId = attendenceSystemSevices.acceptStudentDetails( "Surya", "Ratnala",new  CourseDetails(13, "MCA", "3-years"), new LectureDetails(500, 250, 60), new ExamFeeDetails(1000));
		Assert.assertEquals(expectedStudentId, actualStudentId);
	}
	
	@Test
	public void testCalculatePenality() throws StudentDetailsNotFoundException {
		int expectedPenality = 1000;
		int actualPenality = attendenceSystemSevices.calculatePenalty(51);
		Assert.assertEquals(expectedPenality, actualPenality);
	}
	
	@Test(expected=StudentDetailsNotFoundException.class)
	public void testGetStudentDetailsForInvalidData() throws StudentDetailsNotFoundException {
		attendenceSystemSevices.getStudentDetails(111);
	}
	
	@Test
	public void testGetStudentDetailsForValidData() throws StudentDetailsNotFoundException {
		Student expectedStudenDetails = new Student(51, "Devi", "Ratnala", new CourseDetails(11, "B.Tech", "4-Years"), new LectureDetails(500, 450, 50), new ExamFeeDetails(1000));
		Student actualStudenDetails = attendenceSystemSevices.getStudentDetails(51);
		Assert.assertEquals(expectedStudenDetails, actualStudenDetails);
	}
	
	@After
	public void tearDownTestData() {
		/*AMSUtil.STUDENT_ID_COUNTER = 50;
		AMSUtil.students.clear();*/
	}
	
	@AfterClass
	public static void tearDownTestEnv() {
		 
		attendenceSystemSevices = null;
	}
}
