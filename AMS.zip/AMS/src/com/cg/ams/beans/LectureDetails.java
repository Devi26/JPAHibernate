package com.cg.ams.beans;

import javax.persistence.Embeddable;

@Embeddable
public class LectureDetails {

	private int noOfLecturesConducted, noOfLecturesAttented, noOfSubjects;
	private double attendencePerctge;

	public LectureDetails() {}
	
	public LectureDetails(int noOfLecturesConducted, int noOfLecturesAttented) {
		super();
		this.noOfLecturesConducted = noOfLecturesConducted;
		this.noOfLecturesAttented = noOfLecturesAttented;
	}

	public LectureDetails(int noOfLecturesConducted, int noOfLecturesAttented, int noOfSubjects) {
		super();
		this.noOfLecturesConducted = noOfLecturesConducted;
		this.noOfLecturesAttented = noOfLecturesAttented;
		this.noOfSubjects = noOfSubjects;
	}

	public int getNoOfLecturesConducted() {
		return noOfLecturesConducted;
	}

	public void setNoOfLecturesConducted(int noOfLecturesConducted) {
		this.noOfLecturesConducted = noOfLecturesConducted;
	}

	public int getNoOfLecturesAttented() {
		return noOfLecturesAttented;
	}

	public void setNoOfLecturesAttented(int noOfLecturesAttented) {
		this.noOfLecturesAttented = noOfLecturesAttented;
	}

	public int getNoOfSubjects() {
		return noOfSubjects;
	}

	public void setNoOfSubjects(int noOfSubjects) {
		this.noOfSubjects = noOfSubjects;
	}

	public double getAttendencePerctge() {
		return attendencePerctge;
	}

	public void setAttendencePerctge(double attendencePerctge) {
		this.attendencePerctge = attendencePerctge;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(attendencePerctge);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + noOfLecturesAttented;
		result = prime * result + noOfLecturesConducted;
		result = prime * result + noOfSubjects;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LectureDetails other = (LectureDetails) obj;
		if (Double.doubleToLongBits(attendencePerctge) != Double.doubleToLongBits(other.attendencePerctge))
			return false;
		if (noOfLecturesAttented != other.noOfLecturesAttented)
			return false;
		if (noOfLecturesConducted != other.noOfLecturesConducted)
			return false;
		if (noOfSubjects != other.noOfSubjects)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "LectureDetails [noOfLecturesConducted=" + noOfLecturesConducted + ", noOfLecturesAttented="
				+ noOfLecturesAttented + ", noOfSubjects=" + noOfSubjects + ", attendencePerctge=" + attendencePerctge
				+ "]";
	}
}
