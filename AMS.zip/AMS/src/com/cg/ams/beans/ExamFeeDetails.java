package com.cg.ams.beans;

import javax.persistence.Embeddable;

@Embeddable
public class ExamFeeDetails {

	private int penaltyToBePaid, examFeeToBePaid, totalExamFeeToBePaid;

	public ExamFeeDetails() {}

	public ExamFeeDetails(int examFeeToBePaid) {
		super();
		this.examFeeToBePaid = examFeeToBePaid;
	}

	public ExamFeeDetails(int penaltyToBePaid, int examFeeToBePaid, int totalExamFeeToBePaid) {
		super();
		this.penaltyToBePaid = penaltyToBePaid;
		this.examFeeToBePaid = examFeeToBePaid;
		this.totalExamFeeToBePaid = totalExamFeeToBePaid;
	}

	public int getPenaltyToBePaid() {
		return penaltyToBePaid;
	}

	public void setPenaltyToBePaid(int penaltyToBePaid) {
		this.penaltyToBePaid = penaltyToBePaid;
	}

	public int getExamFeeToBePaid() {
		return examFeeToBePaid;
	}

	public void setExamFeeToBePaid(int examFeeToBePaid) {
		this.examFeeToBePaid = examFeeToBePaid;
	}

	public int getTotalExamFeeToBePaid() {
		return totalExamFeeToBePaid;
	}

	public void setTotalExamFeeToBePaid(int totalExamFeeToBePaid) {
		this.totalExamFeeToBePaid = totalExamFeeToBePaid;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + examFeeToBePaid;
		result = prime * result + penaltyToBePaid;
		result = prime * result + totalExamFeeToBePaid;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExamFeeDetails other = (ExamFeeDetails) obj;
		if (examFeeToBePaid != other.examFeeToBePaid)
			return false;
		if (penaltyToBePaid != other.penaltyToBePaid)
			return false;
		if (totalExamFeeToBePaid != other.totalExamFeeToBePaid)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ExamFeeDetails [penaltyToBePaid=" + penaltyToBePaid + ", examFeeToBePaid=" + examFeeToBePaid
				+ ", totalExamFeeToBePaid=" + totalExamFeeToBePaid + "]";
	}
}
