package com.cg.ams.client;

import com.cg.ams.beans.CourseDetails;
import com.cg.ams.beans.ExamFeeDetails;
import com.cg.ams.beans.LectureDetails;
import com.cg.ams.beans.Student;
import com.cg.ams.exception.StudentDetailsNotFoundException;
import com.cg.ams.services.AMSServices;
import com.cg.ams.services.AMSServicesImpl;

public class MainClass {

	public static void main(String[] args) {

		try {
			AMSServices attendenceSystemServices = new AMSServicesImpl();
			//calling acceptStudentDetails()
			int studentID1 = attendenceSystemServices.acceptStudentDetails("Devi", "Ratnala", new CourseDetails(11, "B.Tech", "4-Years"), new LectureDetails(500, 450, 50), new ExamFeeDetails(1000));
			int studentID2 = attendenceSystemServices.acceptStudentDetails("Sri", "Ratnala", new CourseDetails(11, "BE", "4-Years"), new LectureDetails(500, 300, 50), new ExamFeeDetails(1000));

			System.out.println("StudentID1 : " + studentID1);
			System.out.println("StudentID1 : " + studentID2);
			//calling calculatePenality()
			System.out.println("Exam fee paid by StudentID1 : " + attendenceSystemServices.calculatePenalty(studentID1));;
			System.out.println("Exam fee paid by StudentID2 : " + attendenceSystemServices.calculatePenalty(studentID2));;
			//calling getStudentDetails()
			System.out.println("StudentID1 details : " + attendenceSystemServices.getStudentDetails(studentID1));
			System.out.println("StudentID2 details : " + attendenceSystemServices.getStudentDetails(studentID2));
			//calling calculatePenality()
			System.out.println("Exam fee paid by StudentID1 : " + attendenceSystemServices.calculatePenalty(studentID1));;
			System.out.println("Exam fee paid by StudentID2 : " + attendenceSystemServices.calculatePenalty(studentID2));;
			//calling getAllStudentDetails()
			System.out.println("All student Details : " + attendenceSystemServices.getAllStudentDetails());

		} catch (StudentDetailsNotFoundException e) {
			e.printStackTrace();
		}


	}
}
