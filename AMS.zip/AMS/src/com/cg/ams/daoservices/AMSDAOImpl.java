package com.cg.ams.daoservices;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.ams.beans.Student;

public class AMSDAOImpl implements  AMSDAO {

	private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Student save(Student student) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(student);
		entityManager.getTransaction().commit();
		entityManager.close();
		return student;
	}

	@Override
	public boolean update(Student student) {
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(student);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public Student findOne(int studentID) {
		return entityManagerFactory.createEntityManager().find(Student.class, studentID);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Student> findAll() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Query query = entityManager.createQuery("from Student s");
		return query.getResultList();
	}
}
