package com.cg.banking.main;
import java.util.List;
import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
	
		BankingServices bankingServices = new BankingServicesImpl();
		Scanner s = new Scanner(System.in);
	
		try {
			while(true) {
				System.out.println("1. open Account ");
				System.out.println("2. Deposit Amount ");
				System.out.println("3. Withdraw Amount ");
				System.out.println("4. To Get Account Details ");
				System.out.println("5. To Get Transcation Details ");
				System.out.println("6. Exit ");
				System.out.println("Enter your choice :  ");
				switch (s.nextInt()) {
				case 1:{
					System.out.println(" Enter Account Type and Initial Balance");
					Account account = bankingServices.openAccount(s.next(), s.nextFloat());
					System.out.println("**********your account Opened**********" );
					System.out.println("Account Details : " + account);	
					
				}
				break;
				case 2:{
					System.out.println("Enter Account Number and amount to be deposited ");
					System.out.println("Current Balance is "+bankingServices.depositAmount(s.nextLong(), s.nextFloat()));
				}
				break;
				case 3:{
					System.out.println("Enter AccountNo, amount and pinNumber");
					System.out.println("After withdrawl the Current Balance : " +bankingServices.withdrawAmount(s.nextLong(), s.nextFloat(), s.nextInt()));
				}
				break;
				case 4:{
					System.out.println("Enter accountNo to get accountDetails");	
					System.out.println("Details of Account : " + bankingServices.getAccountDetails(s.nextLong()));	
				}
				break;
				case 5:{
	                System.out.println("Enter Account Number  :");
	                List<Transaction> transactions = bankingServices.getAccountAllTransaction(s.nextLong());
	                for (int i = 0; i < transactions.size(); i++) {
						System.out.println("Transaction of " + i + transactions.get(i).getTransactionId());
						System.out.println("Transaction of " + i + transactions.get(i).getAmount());
						System.out.println("Transaction of " + i + transactions.get(i).getTransactionType());
					}
				}				
				break;
				case 6:{
					System.out.println("Exit");
		            System.exit(0);
				}				
				break;			
				}
			}
		} catch (InvalidAmountException | InvalidAccountTypeException | BankingServicesDownException | AccountNotFoundException | AccountBlockedException | InsufficientAmountException | InvalidPinNumberException e) {
			e.printStackTrace();
		}
			
		
		
			/*Account account1= bankingServices.openAccount("saving", 5000);
			
			Account account2=bankingServices.openAccount("Saving", 4000);
			
			System.out.println(bankingServices.fundTransfer(2, 1, 2000, account1.getPinNumber()));
			System.out.println(bankingServices.depositAmount(1, 1000));
			System.out.println(account1.getAccountBalance());
			System.out.println("Deatails of Account 1 & 2 : " + account1 +" "+account2);*/
			
			/*//1st Account
			Account account1 = bankingServices.openAccount("Savings", 5000);
			System.out.println("Your account details " + account1);
			System.out.println("****your account Opened****" );
			int pinNumber1 = account1.getPinNumber();
			System.out.println("Your PinNumber generated, which is : " + pinNumber1 );
			float depositAmount1 = bankingServices.depositAmount(1, 2000);
			System.out.println("After depositing, the Amount is : "+depositAmount1);
			float withdrawAmount1 = bankingServices.withdrawAmount(1, 6000, pinNumber1); 
			System.out.println("Transaction completed : " + withdrawAmount1);
			System.out.println("After transaction remaining amount is : " + (depositAmount1-withdrawAmount1) );		
			//2nd Account
			Account account2 = bankingServices.openAccount("Savings", 4000);
			System.out.println("Your account details " + account2);
			System.out.println("****your account Opened****" );
			int pinNumber2 = account2.getPinNumber();
			System.out.println("Your PinNumber generated, which is : " + pinNumber2 );
			float depositAmount2 = bankingServices.depositAmount(2, 2000);
			System.out.println("After depositing, the Amount is : "+depositAmount2);			
			float withdrawAmount2 = bankingServices.withdrawAmount(2, 1000, pinNumber2); 
			System.out.println("Transaction completed : " + withdrawAmount2);
	//		System.out.println("After transaction remaining amount is : " + (depositAmount2-withdrawAmount2) );	
			
			System.out.println("Fund is transffered from 2nd Account to 1st Account " + bankingServices.fundTransfer(1, 2, 2000, pinNumber2));
			//System.out.println("Current Balance in Account 1 & 2 is : " + account1.getAccountBalance()+ " & " + account2.getAccountBalance());
			
			System.out.println(" AccountDetails of a " + account1.getAccountNo() + " is :" + bankingServices.getAccountDetails(1));
		
			System.out.println("All AccountDetails : " + bankingServices.getAllAccountDetails());
			
			System.out.println("All TransactionDetails : " + bankingServices.getAccountAllTransaction(1));
		
			System.out.println("Account1 bal:"+account1.getAccountBalance());*/
		
		
	}
}
