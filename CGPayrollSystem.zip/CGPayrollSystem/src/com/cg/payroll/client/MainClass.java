package com.cg.payroll.client;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.exception.InvalidEmailException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {

	public static void main(String[] args)  {
		
		PayrollServices payrollservices = new PayrollServicesImpl(); 
		
			try {
				int id1 =  payrollservices.acceptAssociateDetails(90000, "Devi", "Ratnala", "IT", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", 35000, 1800, 1800, 14567, "ICICI", "IVIC006I");
				System.out.println("AssociateId1 : " + id1);
				int id2 =  payrollservices.acceptAssociateDetails(180000, "Surya", "Ratnala", "IT", "Analyst", "DFHDG878J", "devi@gmail.com", 12000, 1200, 1400, 12467556,"SBI","SBIN098I");
				System.out.println("AssociateId2 : " + id2);
				
				Associate associate = new Associate();
				associate = payrollservices.getAssociateDetails(id1);
				System.out.println("Details of Associate : " + associate);
				
				System.out.println("Net Salary of AssociateId1 : " + payrollservices.calculateNetSalary(id1));
				System.out.println("Net Salary of AssociateId2 : " + payrollservices.calculateNetSalary(id2));
				
				System.out.println("Details of all Associates : " + payrollservices.getallAssociateDetails()) ;
				
			} catch (InvalidEmailException | AssociateDetailsNotFoundException e) {
				e.printStackTrace();
			}
		
		}
	}

